<!DOCTYPE html>
<html>
<body>

<h1>This is my PHP Test Application</h1>

<?php
echo "Version: 1";
?>

</body>
</html>
